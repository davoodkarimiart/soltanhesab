# Soltan Hesab

Source repository for the Soltan Hesab application, currently at **v0.4.12**.

## Setup

1. Copy `config/config.example.php` to `config/config.php`.
2. Set the database credentials and a unique application secret in `config/config.php`.
3. Create the database and import/apply the SQL migrations in `database/migrations/` in numeric order.
4. Configure the web root to this directory and follow `DEPLOY_CPANEL.md` for production deployment.

Never commit `config/config.php`, runtime logs, backups, uploaded report sources, or production exports.

See `CHANGELOG.md`, `UPGRADE.md`, and `docs/` for release notes, upgrade steps, and test checklists.
